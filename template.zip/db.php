<?php  

$conn = mysqli_connect("localhost", "root", "", "agency");

// if($conn){
// 	echo "connection successful";
// }else{
// 	echo "Connection failed";
// }


?>